# This fuctions returns all exchange codes

import urllib.request, json

api_key = '62270ed9289769.07716311'

def lambda_handler(event, context):
    
    
    eod_url = "https://eodhistoricaldata.com/api/exchanges-list/?api_token="+api_key+"&fmt=json"
    with urllib.request.urlopen(eod_url) as url:
        data = json.loads(url.read())
        us_exchanges = ['NYSE', 'NASDAQ', 'BATS', 'OTCQB', 'PINK', 'OTCQX', 'OTCMKTS', 'NMFQS', 'NYSE MKT','OTCBB', 'OTCGREY', 'BATS', 'OTC']
        for item in us_exchanges:
            us = {}
            us['Name'] = item
            us['Code'] = 'US'
            us['OperatingMIC'] = None
            us['Country'] = 'USA'
            us['Currency'] = 'USD'
            data.append(us)
        data.pop(0)
        return {
            'statusCode': 200,
            'data': data
        }
    
    return {
        'statusCode': 400,
        'data': 125
    }