# function that gets all the portfolio of the user
# only user id is needed
from pymongo import MongoClient
from bson.objectid import ObjectId
    
def lambda_handler(event, context):
    
    if "user_id" not in event or "session" not in event:
        return {
            'statusCode': 400,
            'errorType': 100
        }
                       
    user_id = event['user_id']
    session = event['session']
    objInstance = ObjectId(user_id)
    
    # construct response object
    getAllPortfolioResponse = {}
    getAllPortfolioResponse['portfolio_list'] = []
    
    #check User if he/she already exists with that email
    myclient = MongoClient("mongodb+srv://pport:pport123@pport.anzux.mongodb.net/pport?retryWrites=true&w=majority")
    
    mydb = myclient["pport"]
    mycol = mydb["users"]
    
    if  mycol.find_one({ "_id": objInstance, "session": session }):
        mycol = mydb['shares']
        myquery = {"user_id": objInstance}
        mydoc = mycol.find(myquery)
        for portfolio in mydoc:
            getAllPortfolioResponse['portfolio_list'].append(portfolio)
            
        getAllPortfolioResponse['message'] = 'get all portfolio is succesful'
    else:
        getAllPortfolioResponse = {
            'statusCode': 400,
            'error': {
                'code':   "123",
                'message':  "Invalid user",
                'detail': "User does not exist in the system."
            }
            
        }
        return getAllPortfolioResponse       
    return {
        'statusCode': 200,
        'body': str(getAllPortfolioResponse)
    }
