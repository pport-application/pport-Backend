# function that adds a watchlist to the user
from pymongo import MongoClient
from bson.objectid import ObjectId
    
def lambda_handler(event, context):
    
    if "user_id" not in event or "session" not in event or "item_name" not in event:
        return {
            'statusCode': 400,
            'errorType': 100
        }
                       
    user_id = event['user_id']
    session = event['session']
    objInstance = ObjectId(user_id)
    watchlist_item_name = event['item_name']
    alreadyExisted = False
    

    myclient = MongoClient("mongodb+srv://pport:pport123@pport.anzux.mongodb.net/pport?retryWrites=true&w=majority")
    
    mydb = myclient["pport"]
    mycol = mydb["users"]
    
    if  mycol.find_one({ "_id": objInstance, "session": session }):
        userInfo = mycol.find_one({ "_id": objInstance })
        for item in userInfo["watchlist"]:
            if item == watchlist_item_name:
                alreadyExisted = True
                return {
                    'statusCode': 400,
                    'error': 125
                }
        new_watchlist = userInfo["watchlist"]
        new_watchlist.append(watchlist_item_name)
        myquery = { "_id": objInstance }
        newvalues = { "$set": { "watchlist": new_watchlist } }
        mycol.update_one(myquery, newvalues)
        return {
            'statusCode': 200
        }
    return {
        'statusCode': 400,
        'error': 123
    }

    