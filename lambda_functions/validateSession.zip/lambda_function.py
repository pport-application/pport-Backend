# function that validates the session
from pymongo import MongoClient
from bson.objectid import ObjectId

import random, uuid

def lambda_handler(event, context):
                       
    user_id = event['user_id']
    session = event['session']
    objInstance = ObjectId(user_id)
    
    #check User if he/she already exists with that email
    myclient = MongoClient("mongodb+srv://pport:pport123@pport.anzux.mongodb.net/pport?retryWrites=true&w=majority")
    
    mydb = myclient["pport"]
    mycol = mydb["users"]
    
    if  mycol.find_one({ "_id": objInstance, "session": session }):
        return {
            'statusCode': 200,
        }
    return {
        'statusCode': 400,
        'errorType': 123
    }
        
        
    

