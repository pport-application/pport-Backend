# function that deletes all the password requsts that is old every day
from pymongo import MongoClient
from datetime import datetime, timedelta

   
def lambda_handler(event, context):
                       
    myclient = MongoClient("mongodb+srv://pport:pport123@pport.anzux.mongodb.net/pport?retryWrites=true&w=majority")
    
    mydb = myclient["pport"]
    mycol = mydb["reset_password_requests"]
    
    now = datetime.now()
    # Calculating the 1 hour gap
    past_date_after_1hour = now - timedelta(hours = 1)
    print(past_date_after_1hour)
    
    for x in mycol.find():
        sent_request_time = datetime.strptime(x['sent_time'], "%d/%m/%Y %H:%M:%S")
        if (sent_request_time < past_date_after_1hour):
            mycol.delete_one(x)
        
    return {
        'statusCode': 200
        }
