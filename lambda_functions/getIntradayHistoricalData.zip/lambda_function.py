import urllib.request, json
from pymongo import MongoClient
from bson.objectid import ObjectId

api_key = '62270ed9289769.07716311'

# https://eodhistoricaldata.com/api/intraday/AAPL.US?api_token=62270ed9289769.07716311&interval=5m
def lambda_handler(event, context):
    
    if 'user_id' not in event or 'session' not in event or 'code' not in event:
        return {
            'statusCode': 400,
            'errorType': 100
        }
    user_id = event['user_id']
    session = event['session']
    code = event['code']
    objInstance = ObjectId(user_id)
    
    #check User if he/she already exists with that email
    myclient = MongoClient("mongodb+srv://pport:pport123@pport.anzux.mongodb.net/pport?retryWrites=true&w=majority")
    
    mydb = myclient["pport"]
    mycol = mydb["users"]
    
    if  mycol.find_one({ "_id": objInstance, "session": session }):
        eod_url = "https://eodhistoricaldata.com/api/intraday/"+code+"?api_token="+api_key+"&&interval=5m&fmt=json"
        with urllib.request.urlopen(eod_url) as url:
            data = json.loads(url.read())
            return {
                'statusCode': 200,
                'data': data
            }
    return {
        'statusCode': 400
    }