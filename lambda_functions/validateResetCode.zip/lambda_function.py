# functions that changes password
from pymongo import MongoClient
from datetime import datetime, timedelta

   
def lambda_handler(event, context):
                       
    email = event['email']
    reset_code = event['reset_code']
    
    #check User if he/she already exists with that email
    myclient = MongoClient("mongodb+srv://pport:pport123@pport.anzux.mongodb.net/pport?retryWrites=true&w=majority")
    
    mydb = myclient["pport"]
    mycol = mydb["reset_password_requests"]
    now = datetime.now()
    
    if  mycol.find_one({ "email": email }):

        # datetime object containing current date and time
        myquery = { "email": email, "generated_rand": reset_code }
        mydoc = mycol.find(myquery)
        l = 4
        for x in mydoc:
            l = x['generated_rand']
            sent_request_time = datetime.strptime(x['sent_time'], "%d/%m/%Y %H:%M:%S") 
            # Calculating the 15 minutes gap
            future_date_after_15minutes = sent_request_time + timedelta(minutes = 15)
            if (now <= future_date_after_15minutes):
                return {
                    'statusCode': 200
                }
        return {
            'statusCode': 400,
            'error': 124,    # no such reset code
            'body': l,
            'email': email,
            'reset_code': reset_code
            
        }
    return {
        'statusCode': 400,
        'error': 123 # no such email
    }
