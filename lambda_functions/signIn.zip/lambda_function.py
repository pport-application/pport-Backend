# function that logins a user
from pymongo import MongoClient
import uuid

def lambda_handler(event, context):

    if "email" not in event or "password" not in event:
        return {
            'statusCode': 400,
            'errorType': 100
        }
    email = str(event["email"])
    password = str(event["password"])
    
    # construct response object
    loginResponse = {}
    
    # check User if he/she already exists with that email
    myclient = MongoClient("mongodb+srv://pport:pport123@pport.anzux.mongodb.net/pport?retryWrites=true&w=majority")
    
    mydb = myclient["pport"]
    mycol = mydb["users"]
    
    if  mycol.find_one({ "email": email, "password": password }):
        myquery = { "email": email }
        newvalues = { "$set": { "session": str(uuid.uuid1()) } }
        mycol.update_one(myquery, newvalues)
        item = mycol.find_one({ "email": email, "password": password })
        loginResponse['user_id'] = str(item.get('_id'))
        loginResponse['session'] = item.get('session')
        loginResponse['name'] = item.get('name')
        loginResponse['surname'] = item.get('surname')
        loginResponse['email'] = item.get('email')
        loginResponse['watchlist'] = item.get('watchlist')
        myclient.close()
        return {
            'statusCode': 200,
            'body': loginResponse
        }
    myclient.close()
    return {
        'statusCode': 400,
        'errorType': 123
    }
    
