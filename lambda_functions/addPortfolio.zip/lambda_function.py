# add portfolio (buy portfolio) - session eklenecek
# portfolio'dan currency ve cost kaldırdım
from pymongo import MongoClient
from bson.objectid import ObjectId
def lambda_handler(event, context):
    
    if "user_id" not in event or "ticker" not in event or "total_number" not in event or "value" not in event or "profit" not in event:
        return {
            'statusCode': 400,
            'errorType': 100
        }
    
    
    user_id = event['user_id']
    objInstance = ObjectId(user_id)
    ticker = event['ticker']
    total_number = event['total_number']
    #cost = event['cost']
    value = event['value']
    profit = event['profit']
    #currency = event['currency']   
    portfolioItem = {}
    portfolioItem['ticker'] = ticker
    portfolioItem['total_number'] = total_number
    #portfolioItem['cost'] = cost
    portfolioItem['value'] = value
    portfolioItem['profit'] = profit
    #portfolioItem['currency'] = currency                  

    
    myclient = MongoClient("mongodb+srv://pport:pport123@pport.anzux.mongodb.net/pport?retryWrites=true&w=majority")
    
    mydb = myclient["pport"]
    mycol = mydb["users"]
    
    if  mycol.find_one({ "_id": objInstance}):
        mycol = mydb['portfolio']
        userPortfolio = mycol.find_one({ "user_id": objInstance })
        new_portfolio = userPortfolio['portfolio']
        isExists = False
        for element in new_portfolio:
            if element['ticker'] == ticker:
                element['total_number'] += total_number
                isExists = True
        
        if isExists == False:    
            new_portfolio.append(portfolioItem)
            
        
        #add the money to wallet
        myquery = { "user_id": objInstance }
        newvalues = { "$set": { "portfolio": new_portfolio } }
        mycol.update_one(myquery, newvalues)

    else:
        return {
            'statusCode': 400,
            'error': {
                'code':   "123",
                'message':  "Invalid user",
                'detail': "User does not exist in the system."
            }
        }
            
        
    return {
        'statusCode': 200
    }
