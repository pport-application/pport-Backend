# -*- coding: utf-8 -*-

# forget password function
from pymongo import MongoClient
from datetime import datetime
import random
import smtplib, ssl

   
def lambda_handler(event, context):
    
    if "email" not in event:
        return {
            'statusCode': 400,
            'errorType': 100
        }
                       
    email = event['email']
    
    # construct response object
    forgetPasswordResponse = {}
    
    #check User if he/she already exists with that email
    myclient = MongoClient("mongodb+srv://pport:pport123@pport.anzux.mongodb.net/pport?retryWrites=true&w=majority")
    
    mydb = myclient["pport"]
    mycol = mydb["users"]
    
    if  mycol.find_one({ "email": email }):
        # datetime object containing current date and time
        now = datetime.now()
        # dd/mm/YY H:M:S
        dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
        mycol = mydb["reset_password_requests"]
        randomNum = random.randint(1000, 9999)
        mydict = { "email": email, "sent_time": dt_string, "generated_rand": randomNum }
        mycol.insert_one(mydict)
        
        port = 465  # For SSL
        smtp_server = "smtp.gmail.com"
        sender_email = "pport.application@gmail.com"  # Enter your address
        receiver_email = email  # Enter receiver address
        password = "zpgmrtlimodxgvmi"
        message = "From: %s\r\nTo: %s\r\nSubject: %s\r\n\r\n Please enter the following number in pport to reset your password within 15 minutes : %d" % ("pport.application@gmail.com", email, "PPORT Password Reset Request", randomNum)

        context = ssl.create_default_context()
        with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
            server.login(sender_email, password)
            server.sendmail(sender_email, receiver_email, message)
        return {
            'statusCode': 200
        }
    return {
        'statusCode': 400,
        'errorType': 123
    }

    