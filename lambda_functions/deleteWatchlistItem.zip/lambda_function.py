# delete watchlist item of the user
from pymongo import MongoClient
from bson.objectid import ObjectId
    
def lambda_handler(event, context):
    
    if "user_id" not in event or "watclist_item_name" not in event or "session" not in event:
        return {
            'statusCode': 400,
            'errorType': 100
        }
                       
    user_id = event['user_id']
    objInstance = ObjectId(user_id)
    watchlist_item_name = event['watclist_item_name']
    session = event['session']
    
    #check User if he/she already exists with that email
    myclient = MongoClient("mongodb+srv://pport:pport123@pport.anzux.mongodb.net/pport?retryWrites=true&w=majority")
    
    mydb = myclient["pport"]
    mycol = mydb["users"]

    if  mycol.find_one({ "_id": objInstance, "session": session }):
        userInfo = mycol.find_one({ "_id": objInstance })
        for item in userInfo["watchlist"]:
            if item == watchlist_item_name:
                mycol.update_one(userInfo, {"$pull": {"watchlist": watchlist_item_name}})
                return {
                    'statusCode': 200
                }
        # no such watchlist item
        return {
            'statusCode': 400,
            'errorType': 124
        }
  
    # invalid user
    return {
        'statusCode': 400,
        'error': 123
    }
    
