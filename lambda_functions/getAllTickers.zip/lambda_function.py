# This function returns all tickers for searching purposes
import urllib.request, json

api_key = '62270ed9289769.07716311'

def lambda_handler(event, context):
    
    if 'exchange_code' not in event:
        return {
            'statusCode': 400,
            'errorType': 100
        }
    exchange_code = event['exchange_code']
    
    eod_url = "https://eodhistoricaldata.com/api/exchange-symbol-list/"+exchange_code+"?api_token="+api_key+"&fmt=json"
    with urllib.request.urlopen(eod_url) as url:
        data = json.loads(url.read())
        return {
            'statusCode': 200,
            'data': data
        }
    
    return {
        'statusCode': 400,
        'data': 125
    }