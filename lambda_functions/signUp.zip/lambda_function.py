# sign up that creates both empty watchlist, portfolio history, and portfolio

# function that signs up a user
from pymongo import MongoClient
    
def lambda_handler(event, context):
    
    if "name" not in event or "surname" not in event or "email" not in event or "password" not in event:
        return {
            'statusCode': 400,
            'errorType': 100
        }
    
    name = event['name']
    surname = event['surname']                     
    email = event['email']
    password = event['password']
    
    #check User if he/she already exists with that email
    myclient = MongoClient("mongodb+srv://pport:pport123@pport.anzux.mongodb.net/pport?retryWrites=true&w=majority")
    
    mydb = myclient["pport"]
    mycol = mydb["users"]
    
    if  mycol.find_one({ "email": email }):
        # user already exits
        return {
            'statusCode': 400,
            'error': 121
        }

    else:
        mydict = { "name": name, "surname": surname, "email": email, "password": password, "watchlist": []}
        mycol.insert_one(mydict)
        user = mycol.find_one({ "email": email })
        user_id = user["_id"]
        mycol = mydb["history"]
        mydict = { "user_id": user_id, "all_history": []}
        mycol.insert_one(mydict)
        mycol = mydb["portfolio"]
        wallet = {}
        wallet["USD"] = 0
        wallet["TRY"] = 0
        wallet["EUR"] = 0
        mydict = { "user_id": user_id, "portfolio": [], "profit": 0, "wallet": wallet }
        mycol.insert_one(mydict)
    return {
        'statusCode': 200
    }
