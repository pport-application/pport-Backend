# functions that changes password
from pymongo import MongoClient
from datetime import datetime, timedelta

   
def lambda_handler(event, context):
    
    if "email" not in event or "reset_code" not in event or "new_password" not in event:
        return {
            'statusCode': 400,
            'errorType': 100
        }
                       
    email = event['email']
    reset_code = event['reset_code']
    new_password = event['new_password']
    
    # construct response object
    changePasswordResponse = {}
    
    #check User if he/she already exists with that email
    myclient = MongoClient("mongodb+srv://pport:pport123@pport.anzux.mongodb.net/pport?retryWrites=true&w=majority")
    
    mydb = myclient["pport"]
    mycol = mydb["reset_password_requests"]
    now = datetime.now()
    
    if  mycol.find_one({ "email": email }):
        # datetime object containing current date and time
        myquery = { "email": email, "generated_rand": reset_code }
        mydoc = mycol.find(myquery)
        for x in mydoc:
            sent_request_time = datetime.strptime(x['sent_time'], "%d/%m/%Y %H:%M:%S") 
            # Calculating the 15 minutes gap
            future_date_after_15minutes = sent_request_time + timedelta(minutes = 15)
            if (now <= future_date_after_15minutes):
                mycol = mydb["users"]
                myquery = { "email": email }
                newvalues = { "$set": { "password": new_password }}
                mycol.update_one(myquery, newvalues)
                changePasswordResponse['message'] = "Your password updated"
                mycol = mydb["reset_password_requests"]
                myquery = { "email": email }
                mycol.delete_many(myquery)
                return {
                    'statusCode': 200
                }
        return {
            'statusCode': 400,
            'error': 124
        }
    return {
        'statusCode': 400,
        'error': 123
    }   
    
