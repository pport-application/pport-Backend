# add money to wallet
from pymongo import MongoClient
from bson.objectid import ObjectId
def lambda_handler(event, context):
    
    if "user_id" not in event or "currency" not in event or "amount" not in event or "session" not in event:
        return {
            'statusCode': 400,
            'errorType': 100
        }
    
    user_id = event['user_id']
    objInstance = ObjectId(user_id)
    currency = event['currency']                     
    amount = event['amount']
    session = event['session']

    
    myclient = MongoClient("mongodb+srv://pport:pport123@pport.anzux.mongodb.net/pport?retryWrites=true&w=majority")
    
    mydb = myclient["pport"]
    mycol = mydb["users"]
    
    if  mycol.find_one({ "_id": objInstance, "session": session}):
        mycol = mydb['portfolio']
        userPortfolio = mycol.find_one({ "user_id": objInstance })
        new_wallet = userPortfolio["wallet"]
        
        if currency in new_wallet:
            new_wallet[currency] = new_wallet[currency] + amount
        else:
            new_wallet[currency] = amount
        
        #add the money to wallet
        myquery = { "user_id": objInstance }
        newvalues = { "$set": { "wallet": new_wallet } }
        mycol.update_one(myquery, newvalues)

    else:
        return {
            'statusCode': 400,
            'error': {
                'code':   "123",
                'message':  "Invalid user",
                'detail': "User does not exist in the system."
            }
        }
            
        
    return {
        'statusCode': 200
    }
