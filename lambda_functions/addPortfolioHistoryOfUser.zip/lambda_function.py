# add portfolio history of a user
from pymongo import MongoClient
from bson.objectid import ObjectId
    
def lambda_handler(event, context):
    
    if "user_id" not in event or "ticker" not in event or "amount" not in event or "cost" not in event or "timestamp" not in event or "typeOfAction" not in event or "session" not in event:
        return {
            'statusCode': 400,
            'errorType': 100
        }
                       
    user_id = event['user_id']
    objInstance = ObjectId(user_id)
    ticker = event['ticker']
    amount = event['amount']
    cost = event['cost']
    timestamp = event['timestamp']
    typeOfAction = event['typeOfAction']
    session = event['session']
    newPortfolioItem = {}
    newPortfolioItem['ticker'] = ticker
    newPortfolioItem['amount'] = amount
    newPortfolioItem['cost'] = cost
    newPortfolioItem['timestamp'] = timestamp
    newPortfolioItem['typeOfAction'] = typeOfAction
    
    # construct response object
    addPortfolioResponse = {}
    
    #check User if he/she already exists with that email
    myclient = MongoClient("mongodb+srv://pport:pport123@pport.anzux.mongodb.net/pport?retryWrites=true&w=majority")
    
    mydb = myclient["pport"]
    mycol = mydb["users"]
    
    if  mycol.find_one({ "_id": objInstance, "session": session}):
        mycol = mydb['history']
        userInfoPortfolioHistory = mycol.find_one({ "user_id": objInstance })
        new_history = userInfoPortfolioHistory["all_history"]
        new_history.append(newPortfolioItem)
        myquery = { "user_id": objInstance }
        newvalues = { "$set": { "all_history": new_history } }
        mycol.update_one(myquery, newvalues)

    else:
        addPortfolioResponse = {
            'statusCode': 400,
            'error': {
                'code':   "123",
                'message':  "Invalid user",
                'detail': "User does not exist in the system."
            }
            
        }
        return addPortfolioResponse
        
    return {
        'statusCode': 200
    }
