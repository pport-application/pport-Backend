# function that signs out the user - deleting the session attribute
from pymongo import MongoClient
from bson.objectid import ObjectId

def lambda_handler(event, context):
    
    if "user_id" not in event or "session" not in event:
        return {
            'statusCode': 400,
            'errorType': 100
        }
    
    user_id = event['user_id']
    objInstance = ObjectId(user_id)
    session = event['session']
    
    #check User if he/she already exists with that email
    myclient = MongoClient("mongodb+srv://pport:pport123@pport.anzux.mongodb.net/pport?retryWrites=true&w=majority")
    
    mydb = myclient["pport"]
    mycol = mydb["users"]
    
    if  mycol.find_one({ "_id": objInstance, "session": session }):
        # db.getCollection('userData').update({}, {$unset: {pi: 1}})
        myquery = { "_id": objInstance }
        newvalues = { "$unset": { "session": 1 } }
        mycol.update_one(myquery, newvalues)
    else:
        return {
            'statusCode': 400,
            'errorType': 123
        }
    return {
        'statusCode': 200
    }