# get all profile Info for the user
from pymongo import MongoClient
from bson.objectid import ObjectId
    
def lambda_handler(event, context):
    
    if "user_id" not in event or "session" not in event:
        return {
            'statusCode': 400,
            'errorType': 100
        }
                       
    user_id = event['user_id']
    session = event['session']
    objInstance = ObjectId(user_id)
    
    # construct response object
    getProfileInfoResponse = {}
    
    #check User if he/she already exists with that email
    myclient = MongoClient("mongodb+srv://pport:pport123@pport.anzux.mongodb.net/pport?retryWrites=true&w=majority")
    
    mydb = myclient["pport"]
    mycol = mydb["users"]
    
    if  mycol.find_one({ "_id": objInstance, "session": session }):
        mydoc = mycol.find_one({ "_id": objInstance })
        getProfileInfoResponse['name'] = mydoc["name"]
        getProfileInfoResponse['surname'] = mydoc["surname"]  
        getProfileInfoResponse['email'] = mydoc["email"]  
    else:
        return {
            'statusCode': 400,
            'error': 123
        }

    return {
        'statusCode': 200,
        'body': getProfileInfoResponse
    }
