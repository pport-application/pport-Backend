# This fuctions returns all exchange codes

import urllib.request, json

api_key = '62270ed9289769.07716311'

def lambda_handler(event, context):
    
    eod_url = "https://eodhistoricaldata.com/api/exchange-symbol-list/FOREX?api_token="+api_key+"&fmt=json"
    with urllib.request.urlopen(eod_url) as url:
        data = json.loads(url.read())
        currencies = []
        forex = []
        for item in data:
            if len(item['Code']) == 3:
                currencies.append(item)
        return {
            'statusCode': 200,
            'data': currencies
        }
    
    return {
        'statusCode': 400,
        'data': 125
    }